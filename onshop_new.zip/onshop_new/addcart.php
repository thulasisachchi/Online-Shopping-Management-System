

<?php

$sqldel="DELETE FROM addcart";

$result=$con->query($sqldel);
				
				
				?>