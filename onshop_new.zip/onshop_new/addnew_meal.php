



<!doctype html>
	<html lang="en">
		<head>
			<!-- Required meta tags -->
			<meta charset="utf-8">
			<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

			<!-- Bootstrap CSS -->
			<link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/css/bootstrap.min.css" integrity="sha384-MCw98/SFnGE8fJT3GXwEOngsV7Zt27NXFoaoApmYm81iuXoPkFOJwJ8ERdknLPMO" crossorigin="anonymous">

			<title>Online Hall Booking</title><link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<meta charset="utf-8">
	<meta content="text/html; charset=iso-8859-2" http-equiv="Content-Type">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	
			
			
			
			<meta http-equiv="content-type" content="text/html; charset=utf-8" />
			<meta name="description" content="">
			<meta name="author" content="JK">
			<meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1" />

			<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
			<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

			<!--java script-->
			<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
			<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
			
					
			<!-- Optional JavaScript -->
			<!-- jQuery first, then Popper.js, then Bootstrap JS -->
			<script src="https://code.jquery.com/jquery-3.3.1.slim.min.js" integrity="sha384-q8i/X+965DzO0rT7abK41JStQIAqVgRVzpbzo5smXKp4YfRvH+8abtTE1Pi6jizo" crossorigin="anonymous"></script>
			<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.14.3/umd/popper.min.js" integrity="sha384-ZMP7rVo3mIykV+2+9J3UJ46jBk0WLaUAdn689aCwoqbBJiSnjAK/l8WvCWPIPm49" crossorigin="anonymous"></script>
			<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.1.3/js/bootstrap.min.js" integrity="sha384-ChfqqxuZUCnJSK3+MXmPNIyE6ZbWh2IMqE241rYiqJxyMiZ6OW/JmZQ5stwEULTy" crossorigin="anonymous"></script>
			
		 
				
	
				<style type="text/css">
						  [class*="col-"] {
						float: left;
						
					}
					.col-1 {width: 8.33%;}
					.col-2 {width: 16.66%;}
					.col-3 {width: 25%;}
					.col-4 {width: 33.33%;}
					.col-5 {width: 41.66%;}
					.col-6 {width: 50%;}
					.col-7 {width: 58.33%;}
					.col-8 {width: 66.66%;}
					.col-9 {width: 75%;}
					.col-10 {width: 83.33%;}
					.col-11 {width: 91.66%;}
					.col-12 {width: 100%;}



					.col-9{

					background-image: url(bg_bot_img.jpg), url(bg_bot_img.gif);
						

					}

					body{
					 ddbackground-image: url(Images/bg_slider.jpg);
					  background-color:#D8D9D***B;
						}
						
					@font-face {
						font-family: navfont;
						src: url(fonts/BreeSerif-Regular.otf);
						
					}
					@font-face {
						font-family:domine;
						src: url(fonts/Domine-Regular.ttf);
					}

					.navbar-brand{
					  padding-left: 30px;

					}

					.navcontent {
						font-family:navfont;

					}
					.navbar-login {
					  color: #319E82;
					  font-size:20px;
					}
					.carousel-item-active {
					  width: auto;
					  height: auto;
					}
					.Greatfood,.dulasarastoryhead {
					  font-family:domine;
					  font-size:33.4pt;
					  text-align: center;
					}
					.cont{
					  text-align:center;
					}
					.GreatfoodCont {
					  text-align:justify-all;
					  font-family:Verdana;
					}
					.bodygreatfood,.dulasarastory {
					  padding-right:270px;
					  padding-left: 270px;
					  padding-top: 100px;
					}

					.Reservetable,.Aboutus {
					  text-align:center;
					  padding-top: 30px;
					}
					.mybutton{
					  background-color:#319E82;
					  font-size:30px;
					  color:white;
					  border-radius:12px;

					}
					.col2 {
					  padding-left: 120px;
					}

					.col3 {
					  padding-left: 120px;
					}
					.col4 {
					  padding-left: 120px;
					  color:White;
					}
					.icons {
					  align-items: center;
					}
					.footer {
  background-color: black;
  padding: 10px;
  text-align: left;
  color: white;
  
}



					a:hover {
					  text-decoration: none;
					}

				</style>


			</head>
			<body>
				

			<img src="17.jpg" style="width:1370px;" alt="background-image">

			<nav class="navbar navbar-light" style="background-color:#16242D;"><!--nav bar -->

		  <!-- Navbar content -->
		  
			   <div class="navbar-left" style="font-family:navfont; font-color:White;">
			  
					
			 <div id="navcontent">


						<a class="navbar-brand" style="color:White;" href="arrangement.php">&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;Arrangement&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
                          
                          <a class="navbar-brand" style="color:White;" href="customerdetails.php">Customer Details			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
						  <a class="navbar-brand" style="color:White;" href="confirmdetails.php">Confirm Details			&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
						<a class="navbar-brand" style="color:White;"href="adminview_booking_details.php" >Booking Details					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
                          <a class="navbar-brand" style="color:White;"href="admin_feedback.php"> Feedback						&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>
                          <a class="navbar-brand" style="color:White;"href="admin_chat.php" >Chat	</a>
						  <a class="navbar-brand" style="color:White;"href="login.php" >logout					&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;</a>


                          
						
						
					</div>

				</div>


				
				
		</nav>

				<!-- Navigation bar end-->  

				<!-- Start of body -->
					<div class=" row">

						<div class="col-lg-10 col-lg-offset-1 w3-white">
							<div class="w3-card-4 w3-col s12 w3-margin">
								<div class="w3-margin">			
									<div class=" ">
										<div class="mealss" style="font-size:22px; padding-left:20px;"> <br> Add a meal 
										</div>
									</div>
									<div class="col-12">
										<form   id="add_meal" method="POST" action="./addnewitem.php" enctype="multipart/form-data">
											<div class="col-6">
												<div class="w3-half w3-padding">      
													<input class="w3-input w3-border" name="meal_id" type="text" placeholder="Meal ID"  id="meal_id"></div>
												<div class="w3-half w3-padding">      
													<input class="w3-input w3-border" name="meal_name" type="text" placeholder="Meal Name"  id="meal_name" required="required"></div>
												<div class="w3-padding">
													
													
													  <textarea class="form-control" placeholder="Meal Description" name="meal_description" rows="5" required="required"></textarea>
	  

												</div>
												<div class="w3-padding">
													<select class="w3-select w3-border" name="eType" data-validation="required" data-validation-error-msg="Please Select a Category" id="eType">
														<option value=""  selected>Select Meal Category</option>
														<option value="BreakFast">BreakFast</option>
														<option value="Lunch">Lunch</option>
														<option value="Dinner" >Dinner</option>
														<option value="BreakFast&Dinner">BreakFast&Dinner</option>
														<option value="Dessert">Dessert</option>
														<option value="Starder">Starder</option>
														 <option value="#" >Others</option>
													  </select>
												</div>
												<div class="w3-padding">
													<input class="w3-input w3-border" name="price" type="text" placeholder="Price (LKR)"  id="price">
												</div>
											</div>

											<div class="col-6">
												<div class="">
													
														<h2>Upload a photo</h2><hr/>
														<div id="imageVal" style="width:100%;height:100%"><img id="myImg" src="fresh.png" alt="meal image" class="w3-image" style="width:68%;height:80%"/>
														</div>
														<br>		
													
														<input type="file" name="photo" id="fileSelect" class="w3-btn w3-block w3-black w3-padding-large">
														<p><strong>Note:</strong> Only .jpg, .jpeg, .gif, .png formats allowed to a max size of 5 MB.</p>
														
														<div class="w3-padding ">
															
															<span id="uploaded_image"></span>
														</div>
													

												</div>
											
												<div class="w3-row-padding w3-margin-bottom">	
													<div class="w3-half">
														<input type="submit" class="w3-btn w3-green w3-block " name="meal_add" value="Add Meal">
													</div> 
													<div class="w3-half">
														<input type="reset" class="w3-btn w3-red w3-block " name="meal-cancel" value="Cancel">
													</div>								
												</div>
															
										</form>
									
											<div id="result"></div>
																				
									</div> 
								</div> 
							</div> 
						</div> 		
					</div>
				</div>










<!-- Footer -->

<div class="footer col-12">
	
	<div class="wrapper">
	<h3>Contact Us</h3>
	<div calss="Media">
	
	<div class="col-3">
	<i class="fa fa-envelope" aria-hidden="true"><a href="https://mail.google.com">jkonlinebooking@gmail.com</a></i></div>
    	<div class="col-3">
	<i class="fa fa-phone" aria-hidden="true">0214901810</i></div>
		<div class="col-3">
    <i class="fa fa-map-marker" aria-hidden="true"><a href="https://www.google.lk/maps/place/Jaffna-Kankesanturai+Rd/@9.7386927,80.0222913,17z/data=!3m1!4b1!4m5!3m4!1s0x3affab4a55b614ef:0x4b8d9f0d125176db!8m2!3d9.7386927!4d80.02448"><address>No 222/9,<br>kks road,<br> jaffna.</address></a></i></div>
<div class="col-3">
<h1 style="text-shadow: 3px 2px black;color:blue;,font-family:Book Antiqua,font-size:100"><sub>J</sub><sup>K</sup>Hall Booking</h1>

<p>JK is a rapidly growing booking service for event venues.</p>

</div>
</div>
</div>
</div>

 
  </body>
</html>