<?php 
											if(isset($_POST["submit"])) {

												

												$sql = "SELECT * FROM season_offers WHERE cus_fname LIKE '%{$_POST["keyname"]}%' OR cus_lname LIKE '%{$_POST["keyname"]}%' OR username LIKE '%{$_POST["keyname"]}%' OR nic LIKE '%{$_POST["keyname"]}%' OR email LIKE '%{$_POST["keyname"]}%'";

											$result = $conn -> query($sql);

					
											if ($result->num_rows>0 ) {


												$i=0;


											  while($row = $result->fetch_assoc()) {
											  		$i++;

													echo "<tr>";
														  echo "<td>"; echo $row['cus_id'];  echo "</td>";
														  echo "<td>"; echo $row['cus_fname'];  echo "</td>";
														  echo "<td>"; echo $row['cus_lname'];  echo "</td>";
														  echo "<td>"; echo $row['username'];  echo "</td>";
														  echo "<td>"; echo $row['nic'];  echo "</td>";
														    echo "<td>"; echo $row['email'];  echo "</td>";
														     echo "<td>"; echo $row['mobile'];  echo "</td>";

														     echo "<td>"; echo $row['status'];  echo "</td>";

														     if($row['status']== true) {

														     	echo "<td><button type='button' class='btn btn-danger'> <a style='color:white;text-decoration:none;'href='admin_deactivate.php?id={$row["cus_id"]}'>Deactivate</a></button></td>";
														     }
														     elseif($row['status'] == false) {

														     	echo "<td><button type='button' class='btn btn-success'> <a style='color:white;text-decoration:none;'href='admin_activate.php?id={$row["cus_id"]}'>Activate</a></button></td>";


														     }
														  





														  echo "</tr>";
														}


											}


												} if(!isset($_POST["submit"])) {

												include 'includes/dbh.inc.php';

												$sql = "SELECT * FROM customer";

											$result = $conn -> query($sql);

					
											if ($result->num_rows>0 ) {


												$i=0;


											  while($row = $result->fetch_assoc()) {
											  		$i++;

													echo "<tr>";
														  echo "<td>"; echo $row['cus_id'];  echo "</td>";
														  echo "<td>"; echo $row['cus_fname'];  echo "</td>";
														  echo "<td>"; echo $row['cus_lname'];  echo "</td>";
														  echo "<td>"; echo $row['username'];  echo "</td>";
														  echo "<td>"; echo $row['nic'];  echo "</td>";
														    echo "<td>"; echo $row['email'];  echo "</td>";
														     echo "<td>"; echo $row['mobile'];  echo "</td>";

														     echo "<td>"; echo $row['status'];  echo "</td>";

														     if($row['status']== true) {

														     	echo "<td><button type='button' class='btn btn-danger'> <a style='color:white;text-decoration:none;'href='admin_deactivate.php?id={$row["cus_id"]}'>Deactivate</a></button></td>";
														     }
														     elseif($row['status'] == false) {

														     	echo "<td><button type='button' class='btn btn-success'> <a style='color:white;text-decoration:none;'href='admin_activate.php?id={$row["cus_id"]}'>Activate</a></button></td>";


														     }
														  





														  echo "</tr>";
														}


											}


												}






											
										?>