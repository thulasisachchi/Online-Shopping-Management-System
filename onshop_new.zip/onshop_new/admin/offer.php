 <?php
session_start();
include("../db.php");

include "sidenav.php";
include "topheader.php";
?>

<div id="result"></div>
					
						 <div class="content">
        <div class="container-fluid">
        
        
         <div class="col-md-14">
            <div class="card ">
              <div class="card-header card-header-primary">
                <h4 class="card-title"> Seassonal Offer</h4>
                
              </div>
              <div class="card-body">
                <div class="table-responsive ps">
                  <table class="table tablesorter " id="page1">
                    <thead class=" text-primary">
					
								<tr class="w3-light-grey">
									<th>ID</th>
									<th>Offer</th>
									<th>Discription</th>
									<th>Status</th>
									<th>Action</th>
								</tr>
							</thead>

																										
							<tbody>
							<?php
							if(isset($_POST["submit"])) {
								include("../db.php");
								
								$sql = "SELECT * FROM season_offers WHERE is_seassion LIKE '%{$_POST["keyname"]}%'"; 
								$result = $con -> query($sql);

					
											if ($result->num_rows>0 ) {


												$i=0;


											  while($row = $result->fetch_assoc()) {
											  		$i++;
													echo "<tr>";
														  echo "<td>"; echo $row['id'];  echo "</td>";
														    
														  ?>
														
														 <td>Seassional Offer </td>
														 <td>20% offer for each product</td>
														 
														 <?php
														
														  echo "<td>"; echo $row['is_seassion'];  echo "</td>";
														  if($row['is_seassion']== true) {

														     	echo "<td><button type='button' class='btn btn-danger'> <a style='color:white;text-decoration:none;'href='offer_deactivate.php?id={$row["id"]}'>Deactivate</a></button></td>";
														     }
														     elseif($row['is_seassion'] == false) {

														     	echo "<td><button type='button' class='btn btn-success'> <a style='color:white;text-decoration:none;'href='offer_activate.php?id={$row["id"]}'>Activate</a></button></td>";


														     }
														  





														  echo "</tr>";
														}
											}
											} if(!isset($_POST["submit"])) {

												include("../db.php");

												$sql = "SELECT * FROM season_offers";

											$result = $con -> query($sql);

					
											if ($result->num_rows>0 ) {


												$i=0;


											  while($row = $result->fetch_assoc()) {
											  		$i++;

													echo "<tr>";
														  echo "<td>"; echo $row['id'];  echo "</td>";
														  
														  ?>
														
														 <td>Seassional Offer </td>
														 <td>20% offer for each product</td>
														 <?php
														
														  echo "<td>"; echo $row['is_seassion'];  echo "</td>";
														  if($row['is_seassion']== true) {

														     	echo "<td><button type='button' class='btn btn-danger'> <a style='color:white;text-decoration:none;'href='offer_deactivate.php?id={$row["id"]}'>Deactivate</a></button></td>";
														     }
														     elseif($row['is_seassion'] == false) {

														     	echo "<td><button type='button' class='btn btn-success'> <a style='color:white;text-decoration:none;'href='offer_activate.php?id={$row["id"]}'>Activate</a></button></td>";


														     }

														  echo "</tr>";
														}


											}


												}


														 

								?>
								
								
	
							</tbody>
						</table>
						
                <div class="ps__rail-x" style="left: 0px; bottom: 0px;"><div class="ps__thumb-x" tabindex="0" style="left: 0px; width: 0px;"></div></div><div class="ps__rail-y" style="top: 0px; right: 0px;"><div class="ps__thumb-y" tabindex="0" style="top: 0px; height: 0px;"></div></div></div>
              </div>
            </div>
			</div>
			</div>
			</div>
						
		
      <?php
include "footer.php";
?>