<?php
	include("../db.php");
	$sql="UPDATE season_offers set is_seassion = 0 where id=".$_GET["id"];
	if($con->query($sql))
	{
		echo "<script>window.open('offer.php?mes=offer Deactivated','_self')</script>";
	}
	else
	{
		echo "<script type='text/javascript'>alert('Error');</script>";
		echo "<script>window.open('offer.php','_self')</script>";
	}
?>