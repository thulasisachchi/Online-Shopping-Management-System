
<?php
session_start();

$conn=new mysqli('localhost','root','','onshop') or die(mysqli_error());
 if(count($_POST)>0){
    $userid=$_SESSION['uid'];
	$crpass=($_POST["cpassword"]);
	$nwpass=($_POST["npassword"]);
	$cnpass=($_POST["cfpassword"]);
		
		
    $sql = "select * from user_info where user_id='$userid' AND password='$crpass' ";
	$sql1 = "select * from user_info_backup where user_id='$userid' AND password='$crpass' ";
    $result = mysqli_query($conn,$sql);
	$result1 = mysqli_query($conn,$sql1);
	if ($row = mysqli_fetch_assoc($result)) {
       $_SESSION['uid']=$row['user_id'];
       $_SESSION['password']=$row['password'];
	  
	   
              		
    if($nwpass==$cnpass){
       $result=mysqli_query($conn,"UPDATE user_info SET password='$nwpass' where user_id='$userid'");
	   $result1=mysqli_query($conn,"UPDATE user_info_backup SET password='$nwpass' where user_id='$userid'");
   	   
        echo ("<SCRIPT LANGUAGE='JavaScript'>
           window.alert('Succesfully changed your password. Login with your new password')
            window.location.href='login_form.php';
            </SCRIPT>");

        }
       else
        {
           echo ("<SCRIPT LANGUAGE='JavaScript'>
           window.alert('Passwords do not match')
            window.location.href='changepassworda.php';
            </SCRIPT>");
       }
	}
     else{
         echo ("<SCRIPT LANGUAGE='JavaScript'>
           window.alert('Current Password do not match')
            window.location.href='changepassworda.php';
            </SCRIPT>");
     }
 }		
    
?>

<html>
<head>
<title>Member's Change Password Page </title>
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<style>

*
{
margin:0;
padding:0;
}

ul {
  list-style-type: none;
  margin: 10px;
  padding: 0;
  overflow: hidden;
  float:right;
  background-color:rgba(0,0,0,0.7);
  font-family:"Roboto",sans-serif;
  font-size:14px;
  font-weight:bold;
  border:2px solid black;
  border-radius:4px;
}


.changepassword{
	width:320px;
	height:550px;
	background:rgba(0,0,0,0.85);
	color:#fff;
	top:55%;
	left:50%; 
	position:absolute;
	transform:translate(-50%,-50%);
	box-sizing:border-box;
	padding:70px 30px;
    border-radius: 10px;

}	
	
.changepassword p{
	margin:0;
	padding:0;
	font-weight:bold;
	font-size:16px;
	
}



.changepassword input{
	width:100%;
	margin-bottom:20px;
}

.changepassword input[type="password"]
{
	border:none;
	border-bottom:1px solid #fff;
	background:transparent;
	outline:none;
	height:40px;
	color:#fff;
	font-size:16px;
	
}

.changepassword input[type="text"]
{
	border:none;
	border-bottom:1px solid #fff;
	background:transparent;
	outline:none;
	height:40px;
	color:#fff;
	font-size:16px;
	
}

.changepassword input[type="submit"]
{
	border:none;
	outline:none;
	height:40px;
	background:blue;
	color:#fff;
	font-size:18px;
	border-radius:20px;
}

.changepassword input[type="submit"]:hover
{
	cursor:pointer;
	background:green;
	color:#000;
	
}

    .changepassword input[type="reset"]
{
	border:none;
	outline:none;
	height:40px;
	background:blue;
	color:#fff;
	font-size:18px;
	border-radius:20px;
}

.changepassword input[type="reset"]:hover
{
	cursor:pointer;
	background:green;
	color:#000;
	
}

h1{
	margin:0;
	padding:0 0 20px;
	text-align:center;
	font-size:26px;
}
  
body{
margin:0;
padding:0;
background-image:linear-gradient(rgba(0,0,0,0.2),rgba(0,0,0,0.2)),url(images/gym1.jpg);
background-size:cover;
background-position:center;
font-family:sans-serif;
background-repeat: no-repeat;
background-attachment: fixed;
background-size: 100% 100%;
}

.change{
	width:100px;
	height:100px;
	border-radius:50%;
	position:absolute;
	top:-50px;
	left:100px;
}



li {
  float: left;
  font-family:"Roboto",sans-serif;
  font-size:15px;
}

li a, .dropbtn {
  display: inline-block;
  color: white;
  text-align: center;
  padding: 14px 16px;
  text-decoration: none;
}

li a:hover, .dropdown:hover .dropbtn {
	background-color:green;
    border:2px solid black;
}

li.dropdown {
  display: inline-block;
}



.dropdown-content {
  display: none;
  position: absolute;
  min-width: 100px;
  background-color:rgba(0,0,0,0.6);
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.6);
  z-index: 1;
}

.dropdown-content a {
  color: white;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
  text-align: left;
}

.dropdown-content a:hover {
	background-color:green;
	}

.dropdown:hover .dropdown-content {
  display: block;
}


</style>
</head>

<body>





<div class="changepassword">
<img src="images/change3.png" class="change">
<h1> Change Password</h1>
<form name="frmChange" action="" method="post" onSubmit="return validatePassword()">




<P>Current Password</P>
<input type="password" name="cpassword" placeholder="Enter Current Password..." required>

<P>New Password</P>
<input type="password" name="npassword" placeholder="Enter New Password..." pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>

<P>Confirm Password</P>
<input type="password" name="cfpassword" placeholder="Enter Confirm Password..." pattern="(?=.*\d)(?=.*[a-z])(?=.*[A-Z]).{8,}" title="Must contain at least one number and one uppercase and lowercase letter, and at least 8 or more characters" required>

<input type="submit" name="submit" value="Change Password" >
<input type="reset" name="reset" value="Reset">

</form>
    </div>

<script type="text/javascript">
function validatePassword() {
var cpassword,npassword,cpassword,output = true;

cpassword = document.frmChange.cpassword;
npassword = document.frmChange.npassword;
cpassword = document.frmChange.confirmpassword;

if(!cpassword.value) {
cpassword.focus();
document.getElementById("cpassword").innerHTML = "required";
output = false;
}
else if(!npassword.value) {
npassword.focus();
document.getElementById("npassword").innerHTML = "required";
output = false;
}
else if(!cpassword.value) {
cpassword.focus();
document.getElementById("cpassword").innerHTML = "required";
output = false;
}
if(npassword.value != cpassword.value) {
npassword.value="";
cpassword.value="";
npassword.focus();
document.getElementById("cpassword").innerHTML = "not same";
output = false;
} 	
return output;
}
</script>


</body>
</html>