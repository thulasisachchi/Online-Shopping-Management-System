
<?php
include "header.php"; 
$errors= array();
$mysqli=new mysqli('localhost','root','','onshop') or die(mysqli_error($mysqli));



if (isset($_POST['submit'])) {
  // receive all input values from the form
 $name=$_POST['name'];
$city=$_POST['city'];
$email=$_POST['email'];
$msg=$_POST['message'];

  
  
  if (count($errors) == 0) {
	
  	$mysqli -> query("INSERT INTO feedback(name,city,email,message) 
  			  VALUES('$name','$city','$email','$msg')") or
			  die($mysqli ->error);
			  
  echo ("<SCRIPT LANGUAGE='JavaScript'>
           window.alert('you have succesfully added your comment')
            window.location.href='feedback.php';
            </SCRIPT>");
	
  }
  else{
	echo("<SCRIPT LANGUAGE='JavaScript'>
           window.alert('Error')
            window.location.href='index.php';
            </SCRIPT>");  
  }
}


?>

<!DOCTYPE html>
<html>
<head>
     <title> Feedback Form </title>
	 
	 <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
	<meta charset="utf-8">
	<meta content="text/html; charset=iso-8859-2" http-equiv="Content-Type">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<meta name="viewport" content="width=device-width, initial-scale=1.0">
	<style>
	{
   margin: 10;
   padding: 10;
   background-color: url(15.jpg) repeat;
  }
  
	{
			box-sizing: border-box;
		}
		
		.header::after {
			content: "";
			clear: both;
			display: table;
		}
		.bottom type::after {
			content: "";
			clear: both;
			display: table;
		}
		
		[class*="col-"] {
			float: left;
			padding: 5px;
		}
		
		.col-1 {width: 8.33%;}
		.col-2 {width: 16.66%;}
		.col-3 {width: 25%;}
		.col-4 {width: 33.33%;}
		.col-5 {width: 41.66%;}
		.col-6 {width: 50%;}
		.col-7 {width: 58.33%;}
		.col-8 {width: 66.66%;}
		.col-9 {width: 75%;}
		.col-10 {width: 83.33%;}
		.col-11 {width: 91.66%;}
		.col-12 {width: 100%;}
	
		.title{
			
			height:1px;
			background-image:url("Aurora-Soft-Blue-abstract-wallpapers-illusions-polish-shape-abstract-aurora-1920x1080.jpg");
			border-radius: 25px 25px 0px 0px;
			font-family:Brush Script MT;
			font-size:25px;
			color: white;
			padding:0.5px;
			line-height:0.5px;
		}
				.header{
			background-image:url("b.jpg");;
			text-decoration: none;
			font-family:Broadway;
			color:white;
			font-size:25px;
			text-align:center;
			height:0.5px;
			}
		
		
		.menu{
		background-color:black;
			text-decoration: none;
			font-family:Times New Roman;
			color:white;
			font-size:25px;
			text-align:center;
		}
		
		form.box::after {
  content: "";
  clear: both;
  display: table;
}
form.box button {
  float: left;
  width: 20%;
  padding: 10px;
  background: #2196F3;
  color: white;
  font-size: 17px;
  border: 1px solid grey;
  border-left: none;
  cursor: pointer;
}

form.box button:hover {
  background: #0b7dda;
}
form.box input[type=text] {
  padding: 10px;
  font-size: 17px;
  border: 1px solid grey;
  float: left;
  width: 80%;
  background: #f1f1f1;
}
		
					
		
		
			.button {
    background-color:lightblue;
    border: none;
    color:Darkblue;
    padding: 10px;
    text-align: center;
    text-decoration: none;
    display: inline-block;
    font-size: 5px;
    margin: 4px 2px;
    cursor: pointer;
}
.footer {
  background-color: black;
  padding: 10px;
  text-align: left;
  color: white;
  
}

.navbar-brand{
      padding:20px;

}

    .navcontent {
        font-family:navfont;

    }
    .navbar-login {
      color: #319E82;
      font-size:20px;
    }
	
	#customers {

  font-family: Verdana;
  border-collapse: collapse;
  width: 50%;
  height:55%;
  margin-left:15%; 
    margin-right:15%;
	margin-bottom:5%;
	font-weight:bold;
	font-size:25px;
	color:black;
}

#customers th,td, #customers {
  border: 2px solid black;
  padding: 10px;
}
#customers th{
	background-color:#ff4d4d;

}



#customers tr:hover {background-color:  #ff6666;}

* {box-sizing: border-box;}
ul {list-style-type: none;}
body {font-family: Verdana, sans-serif;}

.container {
  border-radius: 5px;
  font-size:22px;
  padding: 20px;
  background-image: url('P.jpg')  ;
 
  font-weight:bold;
  color:black;
}

.col-25 {
  float: left;
  width: 25%;
  margin-top: 6px;
}

.col-75 {
  float: left;
  width: 75%;
  margin-top: 6px;
}

/* Clear floats after the columns */
.row:after {
  content: "";
  display: table;
  clear: both;
}
label {
  padding: 12px 12px 12px 0;
  display: inline-block;
}

input[type=submit] {
  background-color: #4CAF50;
  color: black;
  padding: 12px 20px;
  border: none;
  border-radius: 4px;
  cursor: pointer;
  float: right;
}

input[type=submit]:hover {
  background-color: #45a049;
}
.button {
  background-color:#ff4d4d;
  border: none;
  color: white;
  padding: 20px;
  text-align: center;
  text-decoration: none;
  display: inline-block;
  font-size: 16px;
  margin: 4px 2px;
  cursor: pointer;
  border-radius: 12px;
  float:right;
}
.dropbtn {
  background-color: #ff4d4d;
  color: white;
  padding: 16px;
  font-size: 30px;
  border: none;
  font-family:Times New Roman;
}

.dropdown {
  position: relative;
  display: inline-block;
}

.dropdown-content {
  display: none;
  position: absolute;
  background-color: white;
  min-width: 160px;
  box-shadow: 0px 8px 16px 0px rgba(0,0,0,0.2);
  z-index: 1;
}

.dropdown-content a {
  color: black;
  padding: 12px 16px;
  text-decoration: none;
  display: block;
}

.dropdown-content a:hover {background-color:#ff4d4d ;}

.dropdown:hover .dropdown-content {display: block;}

.dropdown:hover .dropbtn {background-color: #ff4d4d;}

table {
  font-family: arial, sans-serif;
  border-collapse: collapse;
  width: 100%;
}

td, th {
  border: 1px solid #dddddd;
  text-align: left;
  padding: 8px;
}

tr:nth-child(even) {
  background-color: #dddddd;
}
#page-wrap {
     width: 660px;
     background: white;
     padding: 20px 50px 20px 50px;
     margin: 20px auto;
     min-height: 500px;
     height: auto limportant;	 
	 height: 500px;
}

#contact-area {
    width: 600px;
    margin-top: 25px;
}

#contact-area input, #contact-area textarea {
      padding: 5px;
      width: 471px;
	  font-family: Helvetica,sans-serif;
	  font-size: 1.4em;
	  margin: 0px 0px 10px 0px;
	  border: 2px solid #ccc;
	  
}

#contact-area textarea {
	height: 90px;

}	

#contact-area textarea:focus, #contact-area input:focus {
	border: 2px solid #900;
}

#contact-area input.submit-button {
     width: 100px;
     float:	right;
}

label {
  float: left;
  text-align:right;
  margin-right: 15px;
  width: 100px;
  padding-top: 5px;
  font-size:  1.4em;
}


.success  {
	border: 1px solid;
	margin: 10px 0px;
	padding: 15px 10px 15px 50px;
	background-repeat: no-repeat;
	background-position: 10px center;
	color: #4F8A10;
	background-color: #DFF2BF;
	background-image:url('../image/success.png');
	background-size: 31px 31px;
	font-family: "Helvetica Neue", Helvetica, Arial, sans-serif;
	font-size: 14px;
	font-weight: 600;
	
	
}


#navigation {
          background: #FF4E50;  /* fallback for old browsers */
            background: -webkit-linear-gradient(to right, #F9D423, #FF4E50);  /* Chrome 10-25, Safari 5.1-6 */
            background: linear-gradient(to right, #F9D423, #FF4E50); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

          
        }
        #header {
  
            background: #780206;  /* fallback for old browsers */
            background: -webkit-linear-gradient(to right, #061161, #780206);  /* Chrome 10-25, Safari 5.1-6 */
            background: linear-gradient(to right, #061161, #780206); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */

  
        }
        #top-header {
              
  
            background: #870000;  /* fallback for old browsers */
            background: -webkit-linear-gradient(to right, #190A05, #870000);  /* Chrome 10-25, Safari 5.1-6 */
            background: linear-gradient(to right, #190A05, #870000); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */


        }
        #footer {
            background: #7474BF;  /* fallback for old browsers */
            background: -webkit-linear-gradient(to right, #348AC7, #7474BF);  /* Chrome 10-25, Safari 5.1-6 */
            background: linear-gradient(to right, #348AC7, #7474BF); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */


          color: #1E1F29;
        }
        #bottom-footer {
            background: #7474BF;  /* fallback for old browsers */
            background: -webkit-linear-gradient(to right, #348AC7, #7474BF);  /* Chrome 10-25, Safari 5.1-6 */
            background: linear-gradient(to right, #348AC7, #7474BF); /* W3C, IE 10+/ Edge, Firefox 16+, Chrome 26+, Opera 12+, Safari 7+ */
          

        }
        .footer-links li a {
          color: #1E1F29;
        }
        .mainn-raised {
            
            margin: -7px 0px 0px;
            border-radius: 6px;
            box-shadow: 0 16px 24px 2px rgba(0, 0, 0, 0.14), 0 6px 30px 5px rgba(0, 0, 0, 0.12), 0 8px 10px -5px rgba(0, 0, 0, 0.2);

        }
       
        .glyphicon{
    display: inline-block;
    font: normal normal normal 14px/1 FontAwesome;
    font-size: inherit;
    text-rendering: auto;
    -webkit-font-smoothing: antialiased;
    -moz-osx-font-smoothing: grayscale;
    }
    .glyphicon-chevron-left:before{
        content:"\f053"
    }
    .glyphicon-chevron-right:before{
        content:"\f054"
    }
        

       
        
        	
</style>
</head>

<body>
 

<div class="header col-12">
	<h1 style="font-family:Papyrus">Amigos Online Shopping</h1>
	
		</div>
		
		<nav class="navbar navbar-light" style="background-color:#16242D;">
									
										<div class="menu" style="font-family:navfont; font-color:White;">
											
												<div id="navcontent">
												<br>
													<a class="navbar-brand" style="color:White;" href="index.php">Home</a>
													
													
													<div class="dropdown">
									
														<div class="dropdown-content">
														
											
														
															</div>

													<a class="navbar-brand" style="color:White;" href="feedback.php">Feedback</a>
													<br>
													 
    

		</nav> 
										</div>
										</div>
										</div>

<div id="page-wrap">

	
<h1>Feedback Form</h1>
    
	  <div id="contact-area">
	      
         <form method="request" action="feedback.php" name="user">	

            
					
            <label for="name">Name:</label>
	        <input type="text" name="name" id="Name" />
			
			<label for="city">Town:</label>
	        <input type="text" name="city" id="City" />
		  
		    <label for="email">Email:</label>
	        <input type="text" name="email" id="Email" />
			
			<label for="rating">Rating:</label>
												<div class="w3-padding">
													<select class="w3-select w3-border" name="eType" data-validation="required" data-validation-error-msg="Please Select a Category" id="eType">
														<option value="selected">Rating</option>
														<option value="5">5</option>
														<option value="4">4</option>
														<option selected="3">3</option>
														<option value="2">2</option>
														<option value="1">1</option>
														<option value="#" >Others</option>
													  </select>
												</div>
			
		    <label for="message">Message:</label>
	        <textarea name="message" rows="20" cols="20" id="Message"></textarea>
		  </div>
		  <input type="submit" name="submit" value="Submit" class="submit-button" />
		  
	</form>
	
	 <div style="..."></div>
	</div>
	
	
	<div class="footer col-12">
	
	<div class="wrapper">
	<h3>Contact Us</h3>
	<div class="Media">
	
	<div class="col-3">
	<i class="fa fa-envelope" aria-hidden="true"><a href="https://mail.google.com">Amigos@gmail.com</a></i></div>
    	<div class="col-3">
	<i class="fa fa-phone" aria-hidden="true">0557489647</i></div>
		<div class="col-3">
    <i class="fa fa-map-marker" aria-hidden="true"><a href="https://www.google.lk/maps/place/Jaffna-Kankesanturai+Rd/@9.7386927,80.0222913,17z/data=!3m1!4b1!4m5!3m4!1s0x3affab4a55b614ef:0x4b8d9f0d125176db!8m2!3d9.7386927!4d80.02448"><address>No 222/9,<br>kks road,<br> jaffna.</address></a></i></div>
<div class="col-3">
<h1 style="text-shadow: 3px 2px black;color:blue;,font-family:Book Antiqua;,font-size:100">Amigos Online Shopping</h1>

<p>Amigos Online shopping is a form of e-commerce which allows consumers to directly buy goods or services from a seller over the Internet using a web browser. </p></div>

</div>
</div>
</div>

</body>

</html










