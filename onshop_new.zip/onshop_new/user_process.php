<?php

$servername = "localhost";
$username = "root";
$password = "";
$db = "onshop";

// Create connection
$con = mysqli_connect($servername, $username, $password,$db);

// Check connection
if (!$con) {
    die("Connection failed: " . mysqli_connect_error());
}


$name=$_REQUEST['name'];
$city=$_REQUEST['city'];
$email=$_REQUEST['email'];
$msg=$_REQUEST['message'];


$query=mysqli_query($con ,"INSERT INTO feedback(name,city,email,message) VALUES('$name','$city','$email','$msg')") or die(mysqli_error($con));

mysqli_close($con);

header("location:feedback.php?note=success");




?>